﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteWarehouse.Utility
{
    // SD stands for static details
    public class SD
    {
        public const string DefaultProductImage = "default_image.jpg";
        public const string ImageFolder = @"images\ProductImage"; // the image folder it-self @ will scape slash sign

    }
}
