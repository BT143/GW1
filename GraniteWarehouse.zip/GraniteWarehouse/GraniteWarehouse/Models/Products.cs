﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteWarehouse.Models
{
    public class Products
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public bool Available { get; set; }
        public string Image { get; set; }
        public string ShadeColor { get; set; }

        // Navigation Properties
        [Display(Name = "Product Type")] // data anitations for front end, it will change the label
        public int ProductTypeId { get; set; } //forgien key pointing to ProductType Table
        [Display(Name = "Special Tag")]
        public int SpecialTagsId { get; set; } //these are in the [] below

        [ForeignKey("SpecialTagsId")]
        public virtual SpecialTags SpecialTags { get; set; }
        [ForeignKey("ProductTypeId")]
        public virtual ProductTypes ProductTypes { get; set; }
    }
}
